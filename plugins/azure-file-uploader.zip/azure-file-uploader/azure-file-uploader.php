<?php
/*
Plugin Name: Azure File Uploader
Description: Azure file uploader for products 
Auth: Nadeem Iqbal
*/

/*define( 'AFU__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
require_once( AFU__PLUGIN_DIR . 'class.azure-file-uploader.php' );

add_action( 'init', array( 'Azure_Uploader', 'init' ) );
*/
require_once "vendor/autoload.php";
    use MicrosoftAzure\Storage\Blob\BlobRestProxy;
    use MicrosoftAzure\Storage\Blob\BlobSharedAccessSignatureHelper;
    use MicrosoftAzure\Storage\Blob\Models\CreateBlockBlobOptions;
    use MicrosoftAzure\Storage\Blob\Models\CreateContainerOptions;
    use MicrosoftAzure\Storage\Blob\Models\ListBlobsOptions;
    use MicrosoftAzure\Storage\Blob\Models\PublicAccessType;
    use MicrosoftAzure\Storage\Blob\Models\DeleteBlobOptions;
    use MicrosoftAzure\Storage\Blob\Models\CreateBlobOptions;
    use MicrosoftAzure\Storage\Blob\Models\GetBlobOptions;
    use MicrosoftAzure\Storage\Blob\Models\ContainerACL;
    use MicrosoftAzure\Storage\Blob\Models\SetBlobPropertiesOptions;
    use MicrosoftAzure\Storage\Blob\Models\ListPageBlobRangesOptions;
    use MicrosoftAzure\Storage\Common\Exceptions\ServiceException;
    use MicrosoftAzure\Storage\Common\Exceptions\InvalidArgumentTypeException;
    use MicrosoftAzure\Storage\Common\Internal\Resources;
    use MicrosoftAzure\Storage\Common\Internal\StorageServiceSettings;
    use MicrosoftAzure\Storage\Common\Models\Range;
    use MicrosoftAzure\Storage\Common\Models\Logging;
    use MicrosoftAzure\Storage\Common\Models\Metrics;
    use MicrosoftAzure\Storage\Common\Models\RetentionPolicy;
    use MicrosoftAzure\Storage\Common\Models\ServiceProperties;
class FileDownload {
    private $blogContainer;
    private $composerContainer;
    private $connectionString;
    private $blobClient;
    private $account_name;
    private $account_key;
    function __construct() {
        //$this->blogContainer = 'files';
        // live product
        $this->blogContainer = 'files';

        //$this->account_name = 'cmcdevtest';
        // live name
        $this->account_name = 'cmcprod';
        //$this->account_key = 'cWAN9nmh0GmzO43T6o5/xPb+uOhcU7jq2k3/svnj//+YjXdu3Yy3Z0q+d3RCDloqVhqSZFkOFYEZ1WB2TbB4Dw==';
        // live key
        $this->account_key = 'wKrPGy7Ng9xHA0bd24SO9Oa/rOnMIrvV8vu/uSOCmfI/jaXU9Qabil/9RYKu1S/Ip/1+dChlNE0LnEY2/5FS7A==';
        //$this->connectionString = 'DefaultEndpointsProtocol=https;AccountName='.$this->account_name.';AccountKey='.$this->account_key;
        // live string
        //DefaultEndpointsProtocol=https;AccountName=cmcprod;AccountKey=evdBFfIG6tBnGtZEej1B8yYaIYojgsVQyuA1Oc4NkcpnAwoJpaYcPjKTWDh/B5Plo659ArqZRfJM/7CJm9smKQ==;EndpointSuffix=core.windows.net
        $this->connectionString = 'DefaultEndpointsProtocol=https;AccountName='.$this->account_name.';AccountKey='.$this->account_key;
        $this->blobClient = BlobRestProxy::createBlobService($this->connectionString);
        
    }
    public function generateSAS() {


	    $settings = StorageServiceSettings::createFromConnectionString($this->connectionString);
        $accountName = $settings->getName();
        $accountKey = $settings->getKey();

        $helper = new BlobSharedAccessSignatureHelper(
            $accountName,
            $accountKey
        );
        
        $date = new DateTime(date('Y-m-d H:i:s'));
        $date_time = $date->format('Y-m-d').'T'.$date->format('H:i:s').'Z'; 
        $date->modify('+1 day');
        $exp_date_time = $date->format('Y-m-d').'T'.$date->format('H:i:s').'Z'; 
        // Refer to following link for full candidate values to construct a service level SAS
        // https://docs.microsoft.com/en-us/rest/api/storageservices/constructing-a-service-sas

        echo '<br>bloburi ';
        echo $bloburi = $_POST('bloburi');
        //$user_data = Session::get('user_data');
        echo '<br>ext ';
        echo $ext = end(explode('.', $bloburi));
        echo '<br>fileName ';
        $fileName = time().'.'.$ext;

        $my_container = $this->blogContainer.'/'.$fileName;
        $info = [
            'name' => $fileName,
        ];
        $_SESSION['blob_info'] = $info;
        $ip = $_SERVER['REMOTE_ADDR'];
        $sas = $helper->generateBlobServiceSharedAccessSignatureToken(
            Resources::RESOURCE_TYPE_BLOB,
            "$my_container",
            'w',
            date('Y-m-d', strtotime($exp_date_time)).'T'.date('H:i:s', strtotime($exp_date_time)).'Z',
            date('Y-m-d', strtotime($date_time)).'T'.date('H:i:s', strtotime($date_time)).'Z',
            $ip,
            'https,http'
        );
        echo '<br>';
        return 'https://cmcprod.blob.core.windows.net/'.$my_container.'?'.$sas;
    }
}
if(!session_id()) {
	session_start();
}
add_action( 'admin_menu', 'afu_admin_init_callback' );
function afu_admin_init_callback() {
	add_menu_page( $page_title = 'Azure File Upload', $menu_title = 'Azure File Upload', $capability = 'manage_options', $menu_slug= 'azure-file-upload', 'afu_admin_pages', $icon_url = '', $position = null );
	add_submenu_page( $parent_slug='azure-file-upload', $page_title='Resource Upload', $menu_title='Resource Upload', $capability='manage_options', $menu_slug='resource-upload', 'afu_resources_sub_page' );
}

function afu_admin_pages() {
	include "templates/azure-file-upload.php";
}
function afu_resources_sub_page() {
	wp_redirect('http://portal.cmccanada.org/login');
	exit;
}

/* add scripts to admin pages */
function load_custom_wp_admin_style() {
    wp_enqueue_script( 'afu_admin_script_dropdown', plugin_dir_url( __FILE__ ) . 'assets/js/dropdown.min.js');
    wp_enqueue_script( 'afu_admin_script_fineuploader', plugin_dir_url( __FILE__ ) . 'assets/js/azure.fine-uploader.min.js');
    wp_enqueue_script( 'afu_admin_script_form', plugin_dir_url( __FILE__ ) . 'assets/js/form.min.js');
    wp_enqueue_script( 'afu_admin_script_script', plugin_dir_url( __FILE__ ) . 'assets/js/script.js');
    wp_enqueue_style( 'afu_admin_dropdown', plugin_dir_url( __FILE__ ) . 'assets/css/dropdown.min.css');
    wp_enqueue_style( 'afu_admin_form', plugin_dir_url( __FILE__ ) . 'assets/css/form.min.css');
    wp_enqueue_style( 'afu_admin_fineuploader', plugin_dir_url( __FILE__ ) . 'assets/css/fine-uploader.min.css');
    wp_enqueue_style( 'afu_admin_style', plugin_dir_url( __FILE__ ) . 'assets/css/styles.css');
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );

/* rest API for to generate sass and other links */

function afu_azure_get_sas() {
	global $wpdb; // this is how you get access to the database

	$fileDownload = new FileDownload($type);
	echo $fileDownload->generateSAS($blob);
        
	wp_die(); // this is required to terminate immediately and return a proper response
}
add_action( 'wp_ajax_afu_azure_get_sas', 'afu_azure_get_sas' );
/* add add script for ajax*/
add_action( 'admin_footer', 'afu_azure_get_sas_script' ); // Write our JS below here

function afu_azure_get_sas_script() { ?>
	<script type="text/javascript" >
	jQuery(document).ready(function($) {

		var data = {
			'action': 'afu_azure_get_sas',
			'whatever': 1234
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		jQuery.post(ajaxurl, data, function(response) {
			alert('Got this from the server: ' + response);
		});
	});
	</script> <?php
}