(function($){
    $(document).ready(function(){
        
        var file_upload_type = $('.file_upload_type').val();
        var file_upload_title = $('.file_upload_title').val();
        $('.file_upload_title').keyup(function(){
            file_upload_title = $(this).val();
        });

        $('.file_upload_type').change(function(){
            file_upload_type = $(this).val();
        });
        // https://cmcdevtest.blob.core.windows.net/files/11158_saintmarco.mp3
        var uploader = new qq.azure.FineUploader({
            element: document.getElementById('perusal_uploader'),
            debug: true,
            template: 'qq-template-manual-trigger',
            params: {
                    //'submissin_id': $('.hidden_submission_id').val() 
                    'action': 'afu_azure_get_sas',
                },
            request: {
                endpoint: 'https://cmcdevtest.blob.core.windows.net/files/',
                params: {
                    //'submissin_id': $('.hidden_submission_id').val() 
                    'action': 'afu_azure_get_sas',
                },
            },
            signature: {
                endpoint: ajaxurl,
                
            },
            uploadSuccess: {
                endpoint: ajaxurl,
                params: {
                    //'submissin_id': $('.hidden_submission_id').val() 
                    'action': 'afu_azure_get_sas',
                },

                customHeaders: { 'action': 'afu_azure_get_sas' }
            },
            retry: {
               enableAuto: true
            },
            deleteFile: {
                enabled: false
            },
            autoUpload: false,
            callbacks: {
                onAllComplete: function() {
                    
                    /*$('.file_upload_title').val('');
                    var val = $('.file_upload_type').val();
                    $(".file_upload_type option[value='"+val+"']").remove();
                    var val = $('.file_upload_type').val();*/
                    
                    

                    /*$('.response_wrapper').show();
                    $('.response_wrapper .alert-danger').hide();
                    $('.response_wrapper .alert-success').html('File have uploaded successfully.').fadeIn();
                    $('html,body').animate({scrollTop:($('.response_wrapper').offset().top-50)+'px'},500);*/

                },
                onComplete: function(id) {
                  
                },
            }
        });
        qq(document.getElementById("trigger-upload")).attach("click", function() {
            //uploader.setName (0, 'abcdef.mp3');
            $('.response_wrapper').hide();
            $('.response_wrapper .alert-danger').hide();
            $('.response_wrapper .alert-success').hide();
            /*uploader.setEndpoint("{{url('/admin/submissions/generate-sas')}}/"+$('.file_upload_title').val()+'&'+$('.file_upload_type').val()+'&'+$('.hidden_submission_id').val());*/
            uploader.setEndpoint(ajaxurl);
            uploader.uploadStoredFiles();
        });


        /* post form to save fields in session */
        /*$('.ui.form.add_review_form')
        .form({
            fields: {
                rating: ['empty'],
                message: ['empty']
            }
        });
        $('body').on('submit','.form.add_review_form',function(){
            var add_new_booking_form  = $(this);
            var data = add_new_booking_form.serialize();
            add_new_booking_form.addClass('loading');
            var xhr = $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                data: data,
                    success: function(data){
                        add_new_booking_form.removeClass('loading');
                        console.log(data);
                        if(data.success == true){
                            $('.add_review_error_message').addClass('hidden');
                            $('.add_review_success_message').html(data.msg).removeClass('hidden');
                            setTimeout(function(){
                                location.reload(); 
                            },2000);
                        }else{
                            $('.add_review_success_message').addClass('hidden');
                            $('.add_review_error_message').html(data.msg).removeClass('hidden');
                            
                        }
                    },
                    error: function(){
                        add_new_booking_form.removeClass('loading');
                    }
            });
            return false;
            
        });*/
    });
})(jQuery);